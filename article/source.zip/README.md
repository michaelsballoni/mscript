# mscript
A simple, keyword-free scripting language

With no lofty ambitions to supplant PowerShell or python, mscript is for simple scripting, with more power yet easier to use than Windows batch files.
